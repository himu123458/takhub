import { MoreHorizontal } from "lucide-react";

interface HeaderProps {
  title: string;
  subtitle?: string;
}

export default function Header({ title, subtitle }: HeaderProps) {
  return (
    <header className="flex items-center justify-between p-4 border-b border-border bg-background">
      <div className="flex items-center space-x-3">
        <div className="text-primary text-xs bg-primary/10 px-2 py-1 rounded">
          TELEGRAM
        </div>
      </div>
      
      <div className="text-center">
        <h1 className="text-lg font-semibold text-foreground">{title}</h1>
        {subtitle && (
          <p className="text-sm text-muted-foreground">{subtitle}</p>
        )}
      </div>
      
      <MoreHorizontal className="h-5 w-5 text-muted-foreground" />
    </header>
  );
}