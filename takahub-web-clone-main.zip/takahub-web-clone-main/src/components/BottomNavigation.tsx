import { Home, DollarSign, Users, Wallet, User } from "lucide-react";
import { NavLink } from "react-router-dom";

const navItems = [
  { icon: Home, label: "Home", path: "/" },
  { icon: DollarSign, label: "Earn", path: "/earn" },
  { icon: Users, label: "Refer", path: "/refer" },
  { icon: Wallet, label: "Withdraw", path: "/withdraw" },
  { icon: User, label: "Profile", path: "/profile" },
];

export default function BottomNavigation() {
  return (
    <nav className="bottom-nav bg-card border-t border-border">
      <div className="flex justify-around items-center h-16 px-2">
        {navItems.map((item) => (
          <NavLink
            key={item.path}
            to={item.path}
            className={({ isActive }) =>
              `flex flex-col items-center justify-center px-3 py-2 rounded-lg transition-colors ${
                isActive
                  ? "text-primary"
                  : "text-muted-foreground hover:text-foreground"
              }`
            }
          >
            <item.icon className="h-5 w-5 mb-1" />
            <span className="text-xs font-medium">{item.label}</span>
          </NavLink>
        ))}
      </div>
    </nav>
  );
}