import Header from "@/components/Header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function Withdraw() {
  return (
    <div className="telegram-app">
      <Header title="Withdraw Funds" />
      
      <div className="p-4 pb-20">
        {/* Available Balance */}
        <div className="text-center mb-6 p-4 bg-card rounded-lg border border-border">
          <div className="flex justify-between items-center">
            <span className="text-foreground">Available Balance:</span>
            <span className="text-lg font-semibold text-accent">0.0000 USDT</span>
          </div>
        </div>

        {/* Withdrawal Form */}
        <Card>
          <CardHeader>
            <CardTitle className="text-primary">Request Withdrawal</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Withdrawal Method */}
            <div className="space-y-2">
              <Label htmlFor="method" className="text-foreground">Withdrawal Method:</Label>
              <Select>
                <SelectTrigger className="bg-input border-border">
                  <SelectValue placeholder="Select a method" />
                </SelectTrigger>
                <SelectContent className="bg-popover border-border">
                  <SelectItem value="nagad">Nagad (Min. 20 USDT)</SelectItem>
                  <SelectItem value="bkash">bKash (Min. 20 USDT)</SelectItem>
                  <SelectItem value="upay">Upay (Min. 20 USDT)</SelectItem>
                  <SelectItem value="rocket">Rocket (Min. 20 USDT)</SelectItem>
                  <SelectItem value="webmoney">WebMoney (Min. 5 USDT)</SelectItem>
                  <SelectItem value="crypto">Other Crypto</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Amount */}
            <div className="space-y-2">
              <Label htmlFor="amount" className="text-foreground">Amount (USDT):</Label>
              <Input 
                id="amount"
                type="number"
                placeholder="Enter amount"
                className="bg-input border-border"
                min="5"
                step="0.01"
              />
            </div>

            {/* Account/Wallet Address */}
            <div className="space-y-2">
              <Label htmlFor="address" className="text-foreground">Account/Wallet Address:</Label>
              <Input 
                id="address"
                type="text"
                placeholder="Enter account/wallet address"
                className="bg-input border-border"
              />
            </div>

            {/* Submit Button */}
            <Button className="w-full h-12 bg-primary hover:bg-primary/90 mt-6">
              Submit Withdrawal
            </Button>
          </CardContent>
        </Card>

        {/* Minimum Withdrawal Info */}
        <div className="mt-6 p-4 bg-card rounded-lg border border-border">
          <h3 className="font-semibold text-warning mb-2">⚠️ Withdrawal Information</h3>
          <ul className="text-sm text-muted-foreground space-y-1">
            <li>• Minimum withdrawal: 500 TK (≈5 USDT)</li>
            <li>• Processing time: 24-48 hours</li>
            <li>• Withdrawal fee may apply</li>
            <li>• Ensure your account details are correct</li>
          </ul>
        </div>
      </div>
    </div>
  );
}