import Header from "@/components/Header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Copy, Share } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function Refer() {
  const { toast } = useToast();
  const referralLink = "https://t.me/takahubbot?start=ref_takahub";

  const copyLink = () => {
    navigator.clipboard.writeText(referralLink);
    toast({
      title: "Link Copied!",
      description: "Referral link copied to clipboard",
    });
  };

  return (
    <div className="telegram-app">
      <Header title="Refer & Earn" />
      
      <div className="p-4 pb-20">
        {/* Referral Link Section */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-primary">Your Unique Referral Link</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex space-x-2">
              <Input 
                value={referralLink}
                readOnly
                className="flex-1 bg-muted"
              />
              <Button onClick={copyLink} variant="outline" size="sm">
                <Copy className="h-4 w-4 mr-1" />
                Copy Link
              </Button>
            </div>
            <Button className="w-full bg-primary hover:bg-primary/90">
              <Share className="h-4 w-4 mr-2" />
              Share Now
            </Button>
          </CardContent>
        </Card>

        {/* Referral Statistics */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-primary">Referral Statistics</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex justify-between">
              <span className="text-foreground">Times Link Shared/Copied (Overall):</span>
              <span className="font-semibold text-foreground">0</span>
            </div>
            <div className="flex justify-between">
              <span className="text-foreground">Paid Shares Today:</span>
              <span className="font-semibold text-foreground">0/5</span>
            </div>
            <div className="flex justify-between">
              <span className="text-foreground">USDT Earned from Sharing:</span>
              <span className="font-semibold text-foreground">0.0000 USDT</span>
            </div>
          </CardContent>
        </Card>

        {/* Referral Program Details */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-primary">Referral Program Details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-foreground">
              Each time you share or copy your referral link, you can earn{" "}
              <span className="font-semibold text-accent">$0.1 USDT</span>{" "}
              (1 cents)! This reward will be added{" "}
              <span className="font-semibold">1 minute</span> after sharing/copying.
            </p>
            <p className="text-foreground">
              You can earn this reward for up to{" "}
              <span className="font-semibold text-accent">5 shares/copies per day</span>.
            </p>
            <p className="text-foreground">
              There are <span className="font-semibold text-accent">30 referral levels</span>.{" "}
              Unlock additional rewards and bonuses based on your activity.
            </p>
          </CardContent>
        </Card>

        {/* Bonus Information */}
        <div className="bg-card p-4 rounded-lg border border-border">
          <h3 className="font-semibold text-accent mb-2">💡 Pro Tip</h3>
          <p className="text-sm text-muted-foreground">
            Share your referral link on social media, groups, and with friends to maximize your earnings.
            The more people who join through your link, the more you earn!
          </p>
        </div>
      </div>
    </div>
  );
}