import { useEffect } from "react";
import Header from "@/components/Header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { User } from "lucide-react";

export default function Home() {
  useEffect(() => {
    // Add Monetag SDK script
    const script = document.createElement('script');
    script.src = '//libtl.com/sdk.js';
    script.setAttribute('data-zone', '9589709');
    script.setAttribute('data-sdk', 'show_9589709');
    document.body.appendChild(script);

    return () => {
      // Cleanup script on unmount
      document.body.removeChild(script);
    };
  }, []);

  return (
    <div className="telegram-app">
      <Header title="takahub" subtitle="mini app" />
      
      <div className="p-4 pb-20">
        {/* User Info */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-3">
            <div className="h-10 w-10 rounded-full bg-muted flex items-center justify-center">
              <User className="h-6 w-6 text-muted-foreground" />
            </div>
            <div>
              <h2 className="font-semibold text-foreground">Test User (Dev)</h2>
              <p className="text-sm text-muted-foreground">Test Balance: BDT 1</p>
            </div>
          </div>
        </div>

        {/* Today's Monetag Tasks */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-primary">Today's Monetag Tasks</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex justify-between">
              <span className="text-foreground">Daily Limit:</span>
              <span className="font-semibold text-foreground">1000</span>
            </div>
            <div className="flex justify-between">
              <span className="text-foreground">Completed Today:</span>
              <span className="font-semibold text-foreground">0</span>
            </div>
            <div className="flex justify-between">
              <span className="text-foreground">Remaining Today:</span>
              <span className="font-semibold text-foreground">1000</span>
            </div>
          </CardContent>
        </Card>

        {/* Start Task Button */}
        <Button className="w-full h-12 text-lg font-semibold bg-primary hover:bg-primary/90">
          Start Task Monetag (1000 left)
        </Button>

        {/* Monetag Ad Space */}
        <div className="mt-8 p-4 bg-card rounded-lg border border-border">
          <div id="show_9589709" className="min-h-[100px] flex items-center justify-center text-muted-foreground">
            Monetag Ad Space
          </div>
        </div>
      </div>
    </div>
  );
}