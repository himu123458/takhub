import Header from "@/components/Header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export default function Earn() {
  return (
    <div className="telegram-app">
      <Header title="Earn Tasks" />
      
      <div className="p-4 pb-20">
        {/* User Info */}
        <div className="text-center mb-6 p-4 bg-card rounded-lg border border-border">
          <p className="text-sm text-muted-foreground">Test User (Dev) | Test Balance: BDT 1</p>
        </div>

        {/* Today's Monetag Tasks */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-primary">Today's Monetag Tasks</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex justify-between">
              <span className="text-foreground">Daily Limit:</span>
              <span className="font-semibold text-foreground">1000</span>
            </div>
            <div className="flex justify-between">
              <span className="text-foreground">Completed Today:</span>
              <span className="font-semibold text-foreground">0</span>
            </div>
            <div className="flex justify-between">
              <span className="text-foreground">Remaining Today:</span>
              <span className="font-semibold text-foreground">1000</span>
            </div>
          </CardContent>
        </Card>

        {/* Start Task Button */}
        <Button className="w-full h-12 text-lg font-semibold bg-primary hover:bg-primary/90 mb-6">
          Start Task Monetag (1000 left)
        </Button>

        {/* Additional Task Types */}
        <div className="space-y-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-semibold text-foreground">Watch Video Ads</h3>
                  <p className="text-sm text-muted-foreground">Earn 0.1 TK per view</p>
                </div>
                <Button variant="outline" size="sm">Start</Button>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-semibold text-foreground">Click Ads</h3>
                  <p className="text-sm text-muted-foreground">Earn 0.05 TK per click</p>
                </div>
                <Button variant="outline" size="sm">Start</Button>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-semibold text-foreground">Banner Ads</h3>
                  <p className="text-sm text-muted-foreground">Earn 0.02 TK per view</p>
                </div>
                <Button variant="outline" size="sm">View</Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}