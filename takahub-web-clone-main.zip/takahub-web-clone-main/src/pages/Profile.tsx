import Header from "@/components/Header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { User } from "lucide-react";

export default function Profile() {
  return (
    <div className="telegram-app">
      <Header title="Profile" />
      
      <div className="p-4 pb-20">
        {/* User Avatar and Name */}
        <div className="text-center mb-6">
          <Avatar className="h-20 w-20 mx-auto mb-4 border-2 border-primary">
            <AvatarImage src="" alt="User" />
            <AvatarFallback className="bg-primary/10">
              <User className="h-10 w-10 text-primary" />
            </AvatarFallback>
          </Avatar>
          <h2 className="text-xl font-semibold text-foreground mb-2">Hridoy Hassan Himel</h2>
          <p className="text-muted-foreground">Balance: 0.0000 USDT</p>
        </div>

        {/* Today's Tasks Summary */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-primary">Today's Tasks (Overall Summary)</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex justify-between">
              <span className="text-foreground">Monetag Tasks Completed Today:</span>
              <span className="font-semibold text-foreground">0</span>
            </div>
            <div className="flex justify-between">
              <span className="text-foreground">Daily Monetag Limit:</span>
              <span className="font-semibold text-foreground">1000</span>
            </div>
          </CardContent>
        </Card>

        {/* Earnings */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-primary">Earnings</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex justify-between">
              <span className="text-foreground">Total Monetag Earnings (USDT):</span>
              <span className="font-semibold text-foreground">0.0000</span>
            </div>
          </CardContent>
        </Card>

        {/* Recent Withdrawals */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-primary">Recent Withdrawals</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center justify-between py-2">
              <span className="text-foreground">01608***732</span>
              <div className="text-right">
                <div className="text-accent font-semibold">12.8400 USDT</div>
                <div className="text-xs text-accent">Success</div>
              </div>
            </div>
            <div className="flex items-center justify-between py-2">
              <span className="text-foreground">01997***611</span>
              <div className="text-right">
                <div className="text-accent font-semibold">10.7800 USDT</div>
                <div className="text-xs text-accent">Success</div>
              </div>
            </div>
            <div className="flex items-center justify-between py-2">
              <span className="text-foreground">01876***266</span>
              <div className="text-right">
                <div className="text-accent font-semibold">7.0500 USDT</div>
                <div className="text-xs text-accent">Success</div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* User Profile Details */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-primary">User Profile</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex justify-between">
              <span className="text-foreground">Name:</span>
              <span className="font-semibold text-foreground">Hridoy Hassan Himel</span>
            </div>
            <div className="flex justify-between">
              <span className="text-foreground">Phone:</span>
              <span className="font-semibold text-foreground">Not shared</span>
            </div>
            <div className="flex justify-between">
              <span className="text-foreground">Total Balance (USDT):</span>
              <span className="font-semibold text-foreground">0.0000</span>
            </div>
            <div className="flex justify-between">
              <span className="text-foreground">Email:</span>
              <span className="font-semibold text-foreground">user@example.com</span>
            </div>
            <div className="flex justify-between">
              <span className="text-foreground">Last Active:</span>
              <span className="font-semibold text-foreground">Fri Jul 18 2025</span>
            </div>
          </CardContent>
        </Card>

        {/* Logout Button */}
        <Button className="w-full h-12 bg-destructive hover:bg-destructive/90 text-destructive-foreground">
          Logout
        </Button>
      </div>
    </div>
  );
}